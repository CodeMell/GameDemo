#!/bin/sh
echo -ne '\033c\033]0;G4test\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Rezlet.x86_64" "$@"
